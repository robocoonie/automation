var wd = require('wd');
require('colors');
var _ = require("lodash");
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
//var scrape = require("scrape.js");

chai.use(chaiAsPromised);
chai.should();
chaiAsPromised.transferPromiseness = wd.transferPromiseness;

// checking sauce credential
if(!process.env.SAUCE_USERNAME || !process.env.SAUCE_ACCESS_KEY){
    console.warn(
        '\nPlease configure your sauce credential:\n\n' +
        'export SAUCE_USERNAME=<SAUCE_USERNAME>\n' +
        'export SAUCE_ACCESS_KEY=<SAUCE_ACCESS_KEY>\n\n'
    );
    throw new Error("Missing sauce credentials");
}

// http configuration, not needed for simple runs
wd.configureHttp({
    timeout: 60000,
    retryDelay: 15000,
    retries: 5
});

var desired = JSON.parse(process.env.DESIRED || '{browserName: "chrome"}');
desired.name = 'TCOM-UI.molecule.carousel' + ' on ' + desired.browserName;
desired.tags = ['tcom-ui', 'carousel', 'devixd', 'molecule'];
desired.customData = {
    "server": "devixd.toyota.com",
    "component": "carousel",
    "object": "molecule"
};

describe('Molecule Carousel DEVIXD (' + desired.browserName + ')', function() {
    var browser;
    var allPassed = true;
    var testenv = 'http://devcpd122.toyota.com/tcom-ui/';
    var testobj = 'molecules/carousel';
    
    before(function(done) {
        
        var username = process.env.SAUCE_USERNAME;
        var accessKey = process.env.SAUCE_ACCESS_KEY;
        browser = wd.promiseChainRemote("ondemand.saucelabs.com", 80, username, accessKey);
        if(process.env.VERBOSE){
            // optional logging with SauceLabs    
            browser.on('status', function(info) {
                console.log(info.cyan);
            });
            browser.on('command', function(meth, path, data) {
                console.log(' > ' + meth.yellow, path.grey, data || '');
            });
        }
        browser
            .init(desired)
            .nodeify(done);
    });

    afterEach(function(done) {
        allPassed = allPassed && (this.currentTest.state === 'passed');
        done();
    });

    after(function(done) {
        browser
            .quit()
            .sauceJobStatus(allPassed)
            .nodeify(done);
    });

    it("Load carousel molecule", function(done) {
        browser
            //.get('http://devixd.toyota.com/tcom-ui/molecules/carousel/')
            .get(testenv + testobj)
            .title()
            .should.eventually.include('Carousel')
            .nodeify(done);
    });

    it("should load the first image on default", function(done) {
        browser
            .elementByCss('div.slick-slide.slick-active').getAttribute('aria-hidden')
            .should.eventually.include('false')
            .elementByCss('div.slick-slide.slick-active').getAttribute('data-slick-index')
            .should.eventually.include('0')
            .nodeify(done);
    });

    it("should allow for user to advance gallery", function(done) {
        browser
            .elementByClassName('slick-next')
            .click()
            .elementByCss('div.slick-slide.slick-active').getAttribute('aria-hidden')
            .should.eventually.include('false')
            .elementByCss('div.slick-slide.slick-active').getAttribute('data-slick-index')
            .should.eventually.include('1')
            .nodeify(done);
    });

    it("should allow for user to return to previous slide", function(done) {
        browser
            .elementByClassName('slick-prev')
            .click()
            .elementByCss('div.slick-slide.slick-active').getAttribute('aria-hidden')
            .should.become('false')
            .elementByCss('div.slick-slide.slick-active').getAttribute('data-slick-index')
            .should.eventually.include('0')
            .nodeify(done);
    });

    it("should allow for user to go to previous slide", function(done) {
        browser
            .elementByClassName('slick-prev')
            .click()
            .elementByCss('div.slick-slide.slick-active').getAttribute('aria-hidden')
            .should.become('false')
            .elementByCss('div.slick-slide.slick-active').getAttribute('data-slick-index')
            .should.eventually.include('4')
            .nodeify(done);
    });

    it("should be able to advance through all slides", function() {
        for (var i = 0; i < 5; i++) {
            //console.log('slide:',i);
            browser
                .get('http://devixd.toyota.com/tcom-ui/molecules/carousel/')
                .elementByClassName('slick-next')
                .click()
                .elementByCss('div.slick-slide.slick-active').getAttribute('aria-hidden')
                .should.become('false')
                .elementByCss('div.slick-slide.slick-active').getAttribute('data-slick-index')
                .should.eventually.include(i)
        };
    });

    it("should be able to advance backward through all slides", function() {
        for (var i = 4; i > 0; i--) {
            //console.log('slide:',i);
            browser
                .get('http://devixd.toyota.com/tcom-ui/molecules/carousel/')
                .elementByClassName('slick-prev')
                .click()
                .elementByCss('div.slick-slide.slick-active').getAttribute('aria-hidden')
                .should.become('false')
                .elementByCss('div.slick-slide.slick-active').getAttribute('data-slick-index')
                .should.eventually.include(i)
        };
    });
});    