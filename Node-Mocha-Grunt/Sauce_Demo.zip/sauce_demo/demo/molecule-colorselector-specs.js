var wd = require('wd');
require('colors');
var _ = require("lodash");
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
//var scrape = require("scrape.js");

chai.use(chaiAsPromised);
chai.should();
chaiAsPromised.transferPromiseness = wd.transferPromiseness;

// checking sauce credential
if(!process.env.SAUCE_USERNAME || !process.env.SAUCE_ACCESS_KEY){
    console.warn(
        '\nPlease configure your sauce credential:\n\n' +
        'export SAUCE_USERNAME=<SAUCE_USERNAME>\n' +
        'export SAUCE_ACCESS_KEY=<SAUCE_ACCESS_KEY>\n\n'
    );
    throw new Error("Missing sauce credentials");
}

// http configuration, not needed for simple runs
wd.configureHttp( {
    timeout: 60000,
    retryDelay: 15000,
    retries: 5
});

var desired = JSON.parse(process.env.DESIRED || '{browserName: "chrome"}');
desired.name = 'TCOM-UI.molecule.color-selector' + ' on ' + desired.browserName;
desired.tags = ['tcom-ui','color-selector','devixd', 'molecule'];
desired.customData = {
    "server":"devixd.toyota.com",
    "component":"color-selector",
    "object":"molecule"
};

describe('Molecule Color Selector (' + desired.browserName + ')', function() {
    var browser;
    var allPassed = true;
    var testenv = 'http://devcpd122.toyota.com/tcom-ui/';
    var testobj = 'molecules/color-selector';
    
    before(function(done) {
        
        var username = process.env.SAUCE_USERNAME;
        var accessKey = process.env.SAUCE_ACCESS_KEY;
        browser = wd.promiseChainRemote("ondemand.saucelabs.com", 80, username, accessKey);
        if(process.env.VERBOSE){
            // optional logging with SauceLabs    
            browser.on('status', function(info) {
                console.log(info.cyan);
            });
            browser.on('command', function(meth, path, data) {
                console.log(' > ' + meth.yellow, path.grey, data || '');
            });            
        }
        browser
            .init(desired)
            .nodeify(done);
    });

    afterEach(function(done) {
        allPassed = allPassed && (this.currentTest.state === 'passed');  
        done();
    });

    after(function(done) {
        browser
            .quit()
            .sauceJobStatus(allPassed)
            .nodeify(done);
    });

    it("Load color-selector molecule site", function(done) {
        
        browser
            //.get('http://devixd.toyota.com/tcom-ui/molecules/color-selector/')
            .get(testenv + testobj)
            .title()
            .should.eventually.include('Color Selector')
            .nodeify(done);
    });

    it("should include disclaimer text at bottom", function(done) {
        browser
            .elementByClassName('tcom-color-selector-disclaimer')
            .text()
            .should.eventually.include('Prices and colors')
            .nodeify(done);
    });

    xit("grab color swatch array", function(){
        
    });

    it("should display the color name", function(done) {
        browser
            .elementByClassName('tcom-color-selector-name')
            .text()
            .should.eventually.include('METALLIC')
            .nodeify(done);

    });

    it("should display the selector colors area", function(done) {
        browser
            .elementByClassName('tcom-color-selector-colors')
            .nodeify(done);
    });

    it("should be able to click on the color swatches", function() {
        for (var i = 1; i < 6; i++) {
        //console.log('button id',i);
        browser
            .elementByXPath('.//div[2]/button[' + i +']')
            .click()
            .elementByClassName('tcom-color-swatch').getAttribute('class')
            .should.eventually.include('is-on');
        };
        
    });

    it("clicking on any other swatch should update color name", function(done) {
        browser
            .elementByXPath('.//div[2]/button[1]')
            .text()
            .should.not.eventually.include('NAUTICAL')
            .nodeify(done);

    });

    it("clicking on a swatch should indicate swatch selected", function(done) {
        browser
            .elementByXPath('.//div[2]/button[4]')
            .click()
            .elementByXPath('.//div[2]/button[4]').getAttribute('class')
            .should.eventually.include('is-on')
            .nodeify(done);
    });

});